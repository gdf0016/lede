# luci-app-argon-config
Argon Theme Config Plugin

You can set the blur and transparency of the login page of argon theme, and manage the background pictures and videos.