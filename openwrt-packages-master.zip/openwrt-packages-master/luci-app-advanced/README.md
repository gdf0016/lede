# luci-app-advanced
luci-app-advanced 高级设置，包括smartdns，openclash，防火墙，DHCP等。
